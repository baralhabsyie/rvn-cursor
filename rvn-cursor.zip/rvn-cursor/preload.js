const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('rvn', {
  getState: () => ipcRenderer.invoke('state'),
  save: (cfg) => ipcRenderer.invoke('save', cfg)
});
