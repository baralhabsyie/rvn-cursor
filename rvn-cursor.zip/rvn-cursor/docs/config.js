/* =========================================================
   KONFIGURASI WEBSITE RVN CURSOR
   Ubah bagian ini saja.
   ========================================================= */
window.RVN_SITE = {
  repo: 'USERNAME/rvn-cursor',              // akun/repo GitHub tempat Releases
  version: '1.0.0',
  installer: 'Rvn-Cursor-Setup-1.0.0.exe',  // nama file installer di Releases
  saweria: 'https://saweria.co/USERNAME',   // ganti dengan username Saweria kamu
  saweriaCta: 'Traktir kopi di Saweria',
  baseDownloads: 991,                       // angka awal yang ditambahkan ke total unduhan dari GitHub

  // 10 tema karakter (id harus sama dengan nama folder di assets/)
  themes: [
    { id: 'kitty',   name: 'Kitty Kucing',    desc: 'Kucing oranye dengan telinga runcing dan pipi merah muda. Ada hati yang beterbangan.' },
    { id: 'bunny',   name: 'Bunny Manis',     desc: 'Kelinci putih berpipi pink dengan telinga panjang. Dihiasi kilau bintang kecil.' },
    { id: 'bear',    name: 'Beruang Madu',    desc: 'Beruang cokelat yang hangat, dengan daun-daun berguguran di sekelilingnya.' },
    { id: 'fox',     name: 'Rubah Oranye',    desc: 'Rubah lincah dengan moncong putih dan bintang-bintang berkilau.' },
    { id: 'frog',    name: 'Kodok Hijau',     desc: 'Kodok dengan mata menonjol. Gelembung biru naik perlahan di sampingnya.' },
    { id: 'panda',   name: 'Panda Lucu',      desc: 'Panda dengan bintik mata hitam. Confetti warna-warni berjatuhan.' },
    { id: 'dino',    name: 'Dino Hijau',      desc: 'Dinosaurus kecil berduri punggung, dengan percikan bara api.' },
    { id: 'ghost',   name: 'Boo Hantu',       desc: 'Hantu lembut yang melayang, dengan kilau ungu di sekelilingnya.' },
    { id: 'penguin', name: 'Penguin Pilot',   desc: 'Penguin navy dengan paruh oranye. Salju tipis turun pelan.' },
    { id: 'chick',   name: 'Anak Ayam',       desc: 'Anak ayam kuning dengan jambul. Nada musik berterbangan.' }
  ]
};
