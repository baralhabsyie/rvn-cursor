/* Rvn Cursor — skrip situs: tautan, angka unduhan dari GitHub Releases, animasi muncul, dan tema */
(function () {
  const C = window.RVN_SITE;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fmt = n => Number(n).toLocaleString('id-ID');
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const dl = f => `https://github.com/${C.repo}/releases/latest/download/${f}`;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* tautan */
  $$('[data-download], [data-download-nav]').forEach(a => { a.href = dl(C.installer); a.setAttribute('download', C.installer); a.textContent = a.textContent.trim() || 'Unduh'; });
  $$('[data-saweria]').forEach(a => { a.href = C.saweria; a.target = '_blank'; a.rel = 'noopener'; a.textContent = '☕ ' + C.saweriaCta; });
  $$('[data-repo]').forEach(a => { a.href = `https://github.com/${C.repo}`; });
  $$('[data-version]').forEach(el => { el.textContent = C.version; });

  /* angka unduhan */
  const KEY = 'rvn-downloads-v1', TTL = 10 * 60 * 1000;
  async function loadStats() {
    try {
      const c = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (c && Date.now() - c.t < TTL) return c.data;
    } catch (_) {}
    const res = await fetch(`https://api.github.com/repos/${C.repo}/releases?per_page=50`, { headers: { Accept: 'application/vnd.github+json' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const rels = await res.json();
    const releases = rels.filter(r => !r.draft).map(r => ({
      name: r.name || r.tag_name, date: r.published_at, prerelease: r.prerelease,
      count: (r.assets || []).reduce((s, a) => s + (a.download_count || 0), 0)
    }));
    const data = { total: releases.reduce((s, r) => s + r.count, 0), releases };
    try { localStorage.setItem(KEY, JSON.stringify({ t: Date.now(), data })); } catch (_) {}
    return data;
  }
  function countUp(el, to) {
    if (reduce) { el.textContent = fmt(to); return; }
    const t0 = performance.now(), dur = 1300;
    const step = now => {
      const k = Math.min(1, (now - t0) / dur);
      el.textContent = fmt(Math.round(to * (1 - Math.pow(1 - k, 3))));
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  const setStatus = msg => $$('[data-status]').forEach(el => { el.textContent = msg; });
  function render(d) {
    $$('[data-count="total"]').forEach(el => countUp(el, d.total + (C.baseDownloads || 0)));
    setStatus(`Dihitung dari ${d.releases.length} rilis di GitHub`);
    const body = $('#verBody');
    if (body) body.innerHTML = d.releases.length
      ? d.releases.map(r => `<tr><td>${esc(r.name)}${r.prerelease ? ' <small>(pra-rilis)</small>' : ''}</td>` +
          `<td>${new Date(r.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</td>` +
          `<td class="num">${fmt(r.count)}</td></tr>`).join('')
      : '<tr><td colspan="3">Belum ada rilis.</td></tr>';
  }
  async function init() {
    if (C.repo.includes('USERNAME')) {
      setStatus('Atur repo GitHub di config.js untuk menampilkan angka unduhan.');
      $$('[data-count="total"]').forEach(el => { el.textContent = fmt(C.baseDownloads || 0); });
      const body = $('#verBody'); if (body) body.innerHTML = '<tr><td colspan="3">Belum tersambung ke GitHub.</td></tr>';
      return;
    }
    try { render(await loadStats()); }
    catch (err) {
      console.warn(err);
      setStatus('Angka unduhan belum bisa dimuat sekarang. Coba lagi nanti.');
      $$('[data-count="total"]').forEach(el => { el.textContent = '—'; });
      const body = $('#verBody'); if (body) body.innerHTML = '<tr><td colspan="3">Data belum tersedia.</td></tr>';
    }
  }

  /* nav & animasi muncul */
  const nav = $('#nav');
  window.addEventListener('scroll', () => nav && nav.classList.toggle('scrolled', scrollY > 30), { passive: true });
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }),
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  $$('.rv').forEach(el => io.observe(el));

  /* galeri tema: klik untuk memilih di kotak coba */
  window.RVN_SELECT = null; // diisi sandbox.js
  const grid = $('#themeGrid');
  if (grid) {
    grid.innerHTML = C.themes.map(t => `
      <button class="theme rv" type="button" data-theme="${t.id}">
        <img src="assets/preview/${t.id}.gif" alt="Pratinjau tema ${esc(t.name)}" width="448" height="72" loading="lazy">
        <b>${esc(t.name)}</b><small>${esc(t.desc)}</small>
      </button>`).join('');
    $$('.theme', grid).forEach(btn => {
      io.observe(btn);
      btn.addEventListener('click', () => {
        $$('.theme', grid).forEach(b => b.classList.toggle('sel', b === btn));
        if (window.RVN_SELECT) window.RVN_SELECT(btn.dataset.theme);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', init);
  if (document.readyState !== 'loading') init();
})();
