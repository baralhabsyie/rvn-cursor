/* Kotak coba: kursor simulasi memakai sprite dari tiap tema */
(function () {
  const C = window.RVN_SITE;
  const box = document.getElementById('sandbox');
  if (!box) return;
  const fake = document.getElementById('fakeCursor');
  const pick = document.getElementById('sbPick');
  const ripples = document.getElementById('ripples');
  const FRAMES = 16, SCALE = 2, FPS = 15;
  const SZ = 32 * SCALE;

  let theme = C.themes[0].id;
  let role = 'Arrow';
  let x = -100, y = -100, tx = -100, ty = -100;
  let frame = 0, last = 0;

  const spriteUrl = (t, r) => `assets/sprites/${t}-${r}.png`;
  const hotspot = { Arrow: [3, 3], Hand: [14, 6], IBeam: [16, 16] };

  function applySprite() {
    fake.style.backgroundImage = `url(${spriteUrl(theme, role)})`;
    fake.style.backgroundSize = `${FRAMES * SZ}px ${SZ}px`;
    fake.style.width = fake.style.height = SZ + 'px';
  }

  /* pilihan tema di bilah bawah */
  C.themes.forEach(t => {
    const b = document.createElement('button');
    b.type = 'button'; b.title = t.name; b.dataset.theme = t.id;
    const s = document.createElement('span');
    s.style.backgroundImage = `url(${spriteUrl(t.id, 'Arrow')})`;
    s.style.backgroundSize = `${FRAMES * 32}px 32px`;
    s.style.backgroundPositionX = '0px';
    b.appendChild(s);
    b.addEventListener('click', () => setTheme(t.id));
    pick.appendChild(b);
  });
  function setTheme(id) {
    theme = id;
    $$('button', pick).forEach(b => b.classList.toggle('on', b.dataset.theme === id));
    applySprite();
  }
  const $$ = (s, r) => [...r.querySelectorAll(s)];
  window.RVN_SELECT = setTheme;

  /* gerakan mouse & pemilihan jenis kursor */
  box.addEventListener('pointermove', e => {
    const r = box.getBoundingClientRect();
    tx = e.clientX - r.left; ty = e.clientY - r.top;
    fake.style.display = 'block';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const hit = el && el.closest ? el.closest('[data-cursor]') : null;
    let next = 'Arrow';
    if (hit) next = hit.dataset.cursor === 'link' ? 'Hand' : 'IBeam';
    else if (el && el.closest && el.closest('.sb-text')) next = 'IBeam';
    if (next !== role) { role = next; applySprite(); }
  });
  box.addEventListener('pointerleave', () => { fake.style.display = 'none'; });

  box.addEventListener('pointerdown', e => {
    const r = box.getBoundingClientRect();
    const d = document.createElement('div');
    d.className = 'ripple';
    d.style.left = (e.clientX - r.left) + 'px';
    d.style.top = (e.clientY - r.top) + 'px';
    ripples.appendChild(d);
    setTimeout(() => d.remove(), 600);
  });

  /* animasi: posisi mengikuti dengan halus, frame berjalan terus */
  function loop(now) {
    x += (tx - x) * 0.3; y += (ty - y) * 0.3;
    const [hx, hy] = hotspot[role] || [0, 0];
    fake.style.transform = `translate(${x - hx * SCALE}px, ${y - hy * SCALE}px)`;
    if (now - last > 1000 / FPS) {
      frame = (frame + 1) % FRAMES;
      fake.style.backgroundPositionX = (-frame * SZ) + 'px';
      last = now;
    }
    requestAnimationFrame(loop);
  }
  setTheme(theme);
  requestAnimationFrame(loop);
})();
