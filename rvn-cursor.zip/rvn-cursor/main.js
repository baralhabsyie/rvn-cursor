const { app, BrowserWindow, Tray, Menu, nativeImage, globalShortcut, ipcMain } = require('electron');
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

const ASSETS = path.join(__dirname, 'assets');

// Semua jenis kursor Windows yang diganti
const ROLES = [
  'Arrow', 'Help', 'AppStarting', 'Wait', 'Crosshair', 'IBeam', 'Hand', 'UpArrow',
  'SizeNS', 'SizeWE', 'SizeNWSE', 'SizeNESW', 'SizeAll', 'No'
];

const ROLE_LABELS = {
  Arrow: 'Panah normal',
  Help: 'Bantuan',
  AppStarting: 'Sibuk (background)',
  Wait: 'Loading',
  Crosshair: 'Presisi',
  IBeam: 'Pilih teks',
  Hand: 'Pilih tautan',
  UpArrow: 'Panah ke atas',
  SizeNS: 'Resize vertikal',
  SizeWE: 'Resize horizontal',
  SizeNWSE: 'Resize diagonal \u2198',
  SizeNESW: 'Resize diagonal \u2197',
  SizeAll: 'Pindahkan',
  No: 'Tidak tersedia'
};

const REG_PATH = 'HKCU:\\Control Panel\\Cursors';
const CURSOR_CHANGED = `
Add-Type -TypeDefinition @"
using System.Runtime.InteropServices;
public static class CursorNative {
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, string pvParam, uint fWinIni);
}
"@
[CursorNative]::SystemParametersInfo(0x57, 0, $null, 0x03) | Out-Null
`;

let paths = {};
let tray = null;
let settingsWin = null;

// ---------- utilitas PowerShell ----------

function ps(script) {
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  return execFileSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded],
    { encoding: 'utf8', windowsHide: true }
  ).trim();
}

const psStr = (s) => `'${String(s).replace(/'/g, "''")}'`;

// ---------- konfigurasi ----------

function init() {
  const base = path.join(app.getPath('appData'), 'RvnCursor');
  fs.mkdirSync(base, { recursive: true });
  paths = {
    base,
    config: path.join(base, 'config.json'),
    original: path.join(base, 'original-cursors.json'),
    active: path.join(base, 'active')
  };
}

function defaultConfig() {
  return { theme: 'sakura', roles: {}, enabled: true, autostart: true };
}

function loadConfig() {
  try {
    return { ...defaultConfig(), ...JSON.parse(fs.readFileSync(paths.config, 'utf8')) };
  } catch {
    return defaultConfig();
  }
}

function saveConfig(cfg) {
  fs.writeFileSync(paths.config, JSON.stringify(cfg, null, 2));
}

function readThemes() {
  return JSON.parse(fs.readFileSync(path.join(ASSETS, 'themes.json'), 'utf8'));
}

// ---------- kursor sistem ----------

// Ambil nilai kursor asli dari registry (untuk dikembalikan nanti)
function readOriginal() {
  const names = ROLES.map(psStr).join(',');
  try {
    const out = ps(`
$reg = '${REG_PATH}'
$o = @{}
foreach ($n in @(${names})) {
  $o[$n] = (Get-ItemProperty -Path $reg -Name $n -ErrorAction SilentlyContinue).$n
}
$o | ConvertTo-Json -Compress`);
    return JSON.parse(out) || {};
  } catch {
    return {};
  }
}

// Salin file .ani ke folder aktif (folder baru tiap apply agar tidak bentrok dengan file yang sedang dipakai)
function copyActive(cfg) {
  const runDir = path.join(paths.active, String(Date.now()));
  fs.mkdirSync(runDir, { recursive: true });

  const files = {};
  for (const role of ROLES) {
    const themeId = (cfg.roles && cfg.roles[role]) || cfg.theme;
    const src = path.join(ASSETS, 'themes', themeId, `${role}.ani`);
    const dst = path.join(runDir, `${role}.ani`);
    fs.copyFileSync(src, dst);
    files[role] = dst;
  }

  // Bersihkan folder apply sebelumnya
  for (const name of fs.readdirSync(paths.active)) {
    const full = path.join(paths.active, name);
    if (full !== runDir) {
      try { fs.rmSync(full, { recursive: true, force: true }); } catch { /* sedang dipakai, abaikan */ }
    }
  }
  return files;
}

function applyCursors(cfg) {
  const files = copyActive(cfg);
  const sets = ROLES.map(r => `Set-ItemProperty -Path $reg -Name '${r}' -Value ${psStr(files[r])}`).join('\n');
  ps(`$reg = '${REG_PATH}'\n${sets}\n${CURSOR_CHANGED}`);
}

function restoreOriginal() {
  if (!paths.original || !fs.existsSync(paths.original)) return;
  try {
    const orig = JSON.parse(fs.readFileSync(paths.original, 'utf8'));
    const sets = ROLES.map(r => orig[r]
      ? `Set-ItemProperty -Path $reg -Name '${r}' -Value ${psStr(orig[r])}`
      : `Remove-ItemProperty -Path $reg -Name '${r}' -ErrorAction SilentlyContinue`
    ).join('\n');
    ps(`$reg = '${REG_PATH}'\n${sets}\n${CURSOR_CHANGED}`);
    fs.unlinkSync(paths.original);
  } catch (err) {
    console.error('Gagal mengembalikan kursor:', err);
  }
}

function applyAll() {
  const cfg = loadConfig();
  if (cfg.enabled) {
    // Simpan kursor asli hanya sekali, jangan timpa saat apply ulang
    if (!fs.existsSync(paths.original)) {
      fs.writeFileSync(paths.original, JSON.stringify(readOriginal()));
    }
    applyCursors(cfg);
  } else {
    restoreOriginal();
  }
}

// ---------- auto start ----------

function setAutostart(on) {
  const args = app.isPackaged ? ['--hidden'] : [app.getAppPath(), '--hidden'];
  app.setLoginItemSettings({ openAtLogin: on, path: process.execPath, args });
}

// ---------- tray & jendela pengaturan ----------

function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) {
    settingsWin.show();
    settingsWin.focus();
    return;
  }
  settingsWin = new BrowserWindow({
    width: 1000,
    height: 780,
    title: 'Rvn Cursor',
    icon: path.join(ASSETS, 'app-icon.png'),
    autoHideMenuBar: true,
    backgroundColor: '#11131c',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  settingsWin.loadFile(path.join(__dirname, 'settings.html'));
}

function toggleEnabled() {
  const cfg = loadConfig();
  cfg.enabled = !cfg.enabled;
  saveConfig(cfg);
  applyAll();
  refreshTrayMenu();
}

function refreshTrayMenu() {
  const cfg = loadConfig();
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Buka Pengaturan', click: openSettings },
    { label: cfg.enabled ? 'Nonaktifkan kursor Rvn' : 'Aktifkan kursor Rvn', click: toggleEnabled },
    { type: 'separator' },
    { label: 'Keluar', click: () => app.quit() }
  ]));
}

function createTray() {
  tray = new Tray(nativeImage.createFromPath(path.join(ASSETS, 'tray.png')));
  tray.setToolTip('Rvn Cursor');
  tray.on('double-click', openSettings);
  refreshTrayMenu();
}

// ---------- IPC untuk halaman pengaturan ----------

ipcMain.handle('state', () => {
  const themes = readThemes();
  const previews = {};
  for (const t of themes) {
    previews[t.id] = pathToFileURL(path.join(ASSETS, 'preview', `${t.id}.gif`)).href;
  }
  return {
    config: loadConfig(),
    themes,
    previews,
    roles: ROLES.map(id => ({ id, label: ROLE_LABELS[id] }))
  };
});

ipcMain.handle('save', (_e, incoming) => {
  saveConfig({ ...defaultConfig(), ...incoming });
  const cfg = loadConfig();
  setAutostart(cfg.autostart);
  applyAll();
  refreshTrayMenu();
  return cfg;
});

// ---------- lifecycle ----------

function main() {
  init();

  if (process.argv.includes('--restore')) {
    restoreOriginal();
    app.quit();
    return;
  }

  if (!fs.existsSync(paths.config)) saveConfig(defaultConfig());

  applyAll();
  setAutostart(loadConfig().autostart);
  createTray();

  globalShortcut.register('CommandOrControl+Shift+Q', () => app.quit());

  // Saat auto start, jalankan diam-diam di tray
  if (!process.argv.includes('--hidden')) openSettings();
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', openSettings);
  app.whenReady().then(main);
}

// Tetap berjalan walaupun jendela pengaturan ditutup (ada di tray)
app.on('window-all-closed', () => {});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  restoreOriginal();
});
