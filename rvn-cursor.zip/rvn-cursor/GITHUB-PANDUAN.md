# Panduan upload Rvn Cursor ke GitHub

Panduan ini membahas dari awal: membuat repository, mengupload kode dan website,
membuat installer, merilisnya di GitHub Releases, dan mengaktifkan GitHub Pages.

Yang kamu butuhkan:
- Akun GitHub (daftar di https://github.com).
- PC Windows 10/11 untuk membuat installer `.exe`.
- Node.js LTS (https://nodejs.org) dan Git (https://git-scm.com), atau GitHub Desktop (https://desktop.github.com) kalau tidak ingin memakai terminal.

---

## Struktur repository

Satu repository berisi semuanya:

```
rvn-cursor/
├── main.js, preload.js, package.json   ← aplikasi Electron
├── settings.html
├── assets/                              ← kursor (.ani), ikon tray, pratinjau
├── build/icon.ico                       ← ikon installer
├── tools/make_cursors.py                ← generator kursor
├── docs/                                ← WEBSITE (dipublish ke GitHub Pages)
│   ├── index.html, config.js, css/, js/, assets/
├── .gitignore
└── README.md, GITHUB-PANDUAN.md
```

Folder `docs/` dipakai sebagai sumber GitHub Pages, jadi website dan aplikasi
tetap berada dalam satu repository.

---

## Langkah 1: Buat repository di GitHub

1. Login ke https://github.com.
2. Klik ikon **+** di pojok kanan atas, lalu pilih **New repository**.
3. Isi:
   - **Repository name**: `rvn-cursor`
   - **Description**: Kursor karakter animasi untuk Windows
   - **Visibility**: Public (agar website Pages dan tombol download bisa diakses semua orang)
   - Jangan centang *Add a README*, *.gitignore*, atau *license*, karena file-nya sudah ada.
4. Klik **Create repository**.

Catat username GitHub kamu. Contoh di panduan ini memakai `USERNAME`.

---

## Langkah 2: Upload kode ke GitHub

### Cara A: GitHub Desktop (paling mudah)
1. Install GitHub Desktop, lalu login dengan akun GitHub kamu.
2. **File → Add local repository…**, pilih folder `rvn-cursor`.
3. Klik **create a repository** jika muncul pilihan itu, lalu klik **Create repository**.
4. Tulis pesan commit seperti `Rilis awal`, lalu klik **Commit to main**.
5. Klik **Publish repository**, pastikan nama repo `rvn-cursor`, lalu klik **Publish**.

### Cara B: Terminal (Git)
Buka terminal di folder `rvn-cursor`, lalu jalankan:

```bash
git init
git add .
git commit -m "Rilis awal Rvn Cursor"
git branch -M main
git remote add origin https://github.com/USERNAME/rvn-cursor.git
git push -u origin main
```

Saat `git push` meminta login, GitHub tidak lagi menerima password biasa.
Gunakan **Personal Access Token**:
1. GitHub → foto profil → **Settings → Developer settings → Personal access tokens → Tokens (classic)**.
2. **Generate new token**, centang scope `repo`, lalu generate.
3. Salin token, dan pakai sebagai password saat diminta.

### Cara C: Upload lewat browser (tanpa Git)
1. Buka repository `rvn-cursor` di GitHub, klik **Add file → Upload files**.
2. Seret semua isi folder (bukan folder induknya). Ada batas sekitar 100 file per upload, jadi lakukan bertahap jika perlu.
3. Klik **Commit changes**.

> Cara ini kurang praktis untuk folder `docs/` yang berisi banyak file. Cara A atau B lebih disarankan.

---

## Langkah 3: Mengaktifkan GitHub Pages (website)

1. Buka repository → **Settings → Pages**.
2. Di bagian **Build and deployment**:
   - **Source**: *Deploy from a branch*
   - **Branch**: `main`, folder `/docs`
3. Klik **Save**.
4. Tunggu 1–3 menit. Website akan aktif di:
   `https://USERNAME.github.io/rvn-cursor/`

Jika halaman belum muncul, tunggu beberapa menit lalu muat ulang. Di bagian atas
halaman Pages akan ada status *Your site is live at …* setelah berhasil.

---

## Langkah 4: Membuat installer (.exe)

Lakukan ini di PC Windows, di dalam folder `rvn-cursor`:

```bat
npm install
npm run gen
npm run build
```

- `npm install` memasang Electron dan electron-builder (perlu beberapa menit).
- `npm run gen` hanya diperlukan jika kamu mengubah desain kursor. File `assets/` sudah ada.
- `npm run build` menghasilkan installer di folder `dist\`.

Nama hasilnya harus **`Rvn-Cursor-Setup-1.0.0.exe`**. Nama ini sudah diatur di `package.json`
(`artifactName`), dan harus sama dengan nama di `docs/config.js`.

Sebelum merilis, coba jalankan installer dulu di PC kamu:
1. Jalankan `Rvn-Cursor-Setup-1.0.0.exe`.
2. Pastikan kursor berubah, tray berfungsi, dan Ctrl+Shift+Q mengembalikan kursor asli.

---

## Langkah 5: Membuat Release dan mengupload installer

Di sinilah file `.exe` disimpan, dan dari sinilah tombol download dan angka unduhan mengambil data.

1. Buka repository → **Releases** (di kolom kanan) → **Create a new release**.
2. **Choose a tag**: ketik `v1.0.0`, lalu pilih **Create new tag: v1.0.0 on publish**.
3. **Release title**: `Rvn Cursor 1.0.0`
4. **Describe this release**: tulis perubahan singkat, misalnya fitur atau perbaikan.
5. Di bagian **Attach binaries by dropping them here or selecting them**, seret file
   `Rvn-Cursor-Setup-1.0.0.exe` dari folder `dist\`.
6. Pastikan **Set as the latest release** tercentang.
7. Klik **Publish release**.

### Memastikan nama file tepat
Nama file di Releases harus sama persis dengan `installer` di `docs/config.js`:

```js
installer: 'Rvn-Cursor-Setup-1.0.0.exe',
```

Jika tidak sama, tombol download akan menghasilkan halaman 404.

---

## Langkah 6: Mengisi config.js

Buka `docs/config.js`, lalu ganti dua hal:

```js
repo: 'USERNAME/rvn-cursor',              // ganti USERNAME dengan username GitHub kamu
saweria: 'https://saweria.co/USERNAME',   // ganti dengan username Saweria kamu
```

Lalu simpan, dan commit serta push ulang:

```bash
git add docs/config.js
git commit -m "Atur repo dan Saweria"
git push
```

GitHub Pages akan memperbarui website otomatis setelah beberapa menit.

---

## Langkah 7: Pengecekan akhir

1. **Website**: buka `https://USERNAME.github.io/rvn-cursor/`.
2. **Angka unduhan**: harus menampilkan 991 atau lebih, bukan "—".
   Kalau tetap "—", buka `https://api.github.com/repos/USERNAME/rvn-cursor/releases`
   di browser dan pastikan ada data JSON.
3. **Tombol unduh**: klik, dan pastikan file `.exe` langsung terunduh.
   Link yang dipakai:
   `https://github.com/USERNAME/rvn-cursor/releases/latest/download/Rvn-Cursor-Setup-1.0.0.exe`
4. **Saweria**: klik tombol dukung dan pastikan mengarah ke halaman kamu.

---

## Cara merilis versi baru (misalnya 1.1.0)

1. Ubah `version` di `package.json` menjadi `1.1.0`.
2. Ubah `version` dan `installer` di `docs/config.js` menjadi `1.1.0` dan `Rvn-Cursor-Setup-1.1.0.exe`.
3. Jalankan `npm run build` lagi, lalu hasilnya ada di `dist\Rvn-Cursor-Setup-1.1.0.exe`.
4. Commit dan push perubahan kode.
5. Buat release baru dengan tag `v1.1.0`, dan upload file installer baru.
6. Release terbaru otomatis menjadi tautan download utama, dan riwayat versi tetap tersimpan.

> Angka unduhan total menjumlahkan semua rilis, jadi tidak perlu diatur ulang.
> Biarkan `baseDownloads` di `config.js` seperti sebelumnya.

---

## Masalah yang sering muncul

| Gejala | Penyebab dan solusi |
|---|---|
| Tombol download menampilkan 404 | Nama file di Releases tidak sama dengan `installer` di `config.js`. Samakan namanya. |
| Angka unduhan "—" | `repo` di `config.js` masih `USERNAME` atau salah ejaan. Periksa lagi. |
| Website tidak berubah setelah push | Tunggu beberapa menit, lalu hard refresh (Ctrl+F5). Pastikan Pages menunjuk ke `main` dan `/docs`. |
| Upload gagal karena file terlalu besar | GitHub membatasi 100 MB per file. Installer sekitar 90 MB sudah di bawah batas, tapi jangan dimasukkan ke commit biasa. Upload hanya lewat Releases. |
| `git push` ditolak | Repo belum dibuat, atau token tidak punya scope `repo`. |
| Windows SmartScreen memperingatkan | Wajar, karena aplikasi belum di-code-sign. Pengguna pilih *More info → Run anyway*. Ini dijelaskan di website. |
| `npm run build` gagal | Pastikan Node.js LTS terpasang dan dijalankan di Windows. Hapus folder `node_modules` lalu jalankan `npm install` lagi. |

---

## Catatan keamanan
- Jangan pernah mengupload token atau file `.env` ke repository.
- Jika token bocor, hapus di **Settings → Developer settings → Personal access tokens**, lalu buat yang baru.
