#!/usr/bin/env python3
"""
Generator Rvn Cursor v2: karakter hewan lucu, telapak tangan, dan banyak efek.
Jalankan: npm run gen
"""
import colorsys, io, json, math, os, struct
from PIL import Image, ImageChops, ImageDraw, ImageFilter

SIZE = 32
SS = 6
BIG = SIZE * SS
FRAMES = 16
JIFFY = 4
TAU = 2 * math.pi
ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets')
PREVIEW_BG = (27, 29, 42)
INK = (52, 33, 66)
OUTLINE = (40, 24, 52)
LAYERS = ('sil', 'light', 'dark', 'cheek', 'beak', 'accent', 'white', 'ink')
GRAD = Image.linear_gradient('L').resize((BIG, BIG))

ROLES = {
    'Arrow': (3, 3), 'Help': (3, 3), 'AppStarting': (3, 3), 'UpArrow': (16, 2),
    'Hand': (14, 6), 'Wait': (16, 16), 'IBeam': (16, 16), 'Crosshair': (16, 16),
    'SizeAll': (16, 16), 'SizeNS': (16, 16), 'SizeWE': (16, 16),
    'SizeNWSE': (16, 16), 'SizeNESW': (16, 16), 'No': (16, 16),
}
RESIZE_DIR = {'SizeNS': 90, 'SizeWE': 0, 'SizeNWSE': 45, 'SizeNESW': 135}
PREVIEW_ROLES = ['Arrow', 'Hand', 'AppStarting', 'Wait', 'IBeam', 'SizeAll', 'No']

THEMES = {
    'kitty':   dict(name='Kitty Kucing', char='cat', main='#ffb86b', light='#fff1dc', dark='#d9782a',
                    cheek='#ff8fb1', accent='#ff6fa5', beak='#ff8fb1', deco='heart', dc=['#ff6fa5', '#ffb3d1']),
    'bunny':   dict(name='Bunny Manis', char='bunny', main='#fff0f6', light='#ffb3d1', dark='#e0a3c4',
                    cheek='#ff8fb1', accent='#ffd6ea', beak='#ffb3d1', deco='spark', dc=['#ffffff', '#ffd6ea']),
    'bear':    dict(name='Beruang Madu', char='bear', main='#c98b55', light='#f6dfc2', dark='#8a5530',
                    cheek='#ff9b7a', accent='#9be36b', beak='#8a5530', deco='leaf', dc=['#7fd45a', '#f2b33d']),
    'fox':     dict(name='Rubah Oranye', char='fox', main='#ff8a3d', light='#fff7ef', dark='#b84a14',
                    cheek='#ffb08a', accent='#ffe066', beak='#2a1f2a', deco='star', dc=['#ffe066', '#ffffff']),
    'frog':    dict(name='Kodok Hijau', char='frog', main='#7be07a', light='#e8ffe0', dark='#2f8f3d',
                    cheek='#ff9fb4', accent='#9fe8ff', beak='#2f8f3d', deco='bubble', dc=['#9fe8ff', '#d6f7ff']),
    'panda':   dict(name='Panda Lucu', char='panda', main='#ffffff', light='#f2f0f5', dark='#2b2b33',
                    cheek='#ffb3c1', accent='#ffd166', beak='#2b2b33', deco='confetti',
                    dc=['#ff6b6b', '#4ecdc4', '#ffd166', '#7b6cff']),
    'dino':    dict(name='Dino Hijau', char='dino', main='#6fd3a0', light='#d8ffe9', dark='#2a7d5c',
                    cheek='#ff9f7a', accent='#ffb347', beak='#ffb347', deco='ember', dc=['#ffb347', '#ff7a3d']),
    'ghost':   dict(name='Boo Hantu', char='ghost', main='#f1ecff', light='#ffffff', dark='#8170d0',
                    cheek='#ffb3e6', accent='#c7b8ff', beak='#8170d0', deco='spark', dc=['#c7b8ff', '#ffffff']),
    'penguin': dict(name='Penguin Pilot', char='penguin', main='#2d3358', light='#ffffff', dark='#171b33',
                    cheek='#ff9fb4', accent='#bfe9ff', beak='#ffb347', deco='snow', dc=['#ffffff', '#bfe9ff']),
    'chick':   dict(name='Anak Ayam', char='chick', main='#ffe066', light='#fff8cf', dark='#d9a300',
                    cheek='#ff9f9f', accent='#ff9f43', beak='#ff9f43', deco='note', dc=['#ff9f43', '#ffd166']),
}


# ---------- utilitas geometri ----------

def hexrgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def new_mask():
    return Image.new('L', (BIG, BIG), 0)


def P(pts):
    return [(x * SS, y * SS) for x, y in pts]


def pol_ell(cx, cy, rx, ry, ang=0):
    ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    pts = []
    for i in range(40):
        a = TAU * i / 40
        x, y = rx * math.cos(a), ry * math.sin(a)
        pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return pts


def heart_pts(x, y, s):
    pts = []
    for i in range(24):
        a = TAU * i / 24
        hx = 16 * math.sin(a) ** 3
        hy = 13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a)
        pts.append((x + hx * s / 17, y - hy * s / 17))
    return pts


def star_pts(x, y, s, n, inner):
    pts = []
    for i in range(2 * n):
        a = TAU * i / (2 * n) - math.pi / 2
        r = s if i % 2 == 0 else s * inner
        pts.append((x + r * math.cos(a), y + r * math.sin(a)))
    return pts


def head_pts(cx, cy, dx, dy, p):
    tip = (cx + dx * (12 + p), cy + dy * (12 + p))
    bx, by = cx + dx * (7 + p), cy + dy * (7 + p)
    px, py = -dy * 4.2, dx * 4.2
    return [tip, (bx + px, by + py), (bx - px, by - py)]


# ---------- kanvas dengan layer warna ----------

class Art:
    def __init__(self, s=1.0, cx=17.0, cy=17.0):
        self.s, self.cx, self.cy = s, cx, cy
        self.m = {k: new_mask() for k in LAYERS}
        self.d = {k: ImageDraw.Draw(v) for k, v in self.m.items()}

    def T(self, x, y):
        return (self.cx + (x - 17) * self.s, self.cy + (y - 17) * self.s)

    def ell(self, L, x, y, rx, ry=None, ang=0):
        ry = rx if ry is None else ry
        cx, cy = self.T(x, y)
        self.d[L].polygon(P(pol_ell(cx, cy, rx * self.s, ry * self.s, ang)), fill=255)

    def poly(self, L, pts):
        self.d[L].polygon(P([self.T(x, y) for x, y in pts]), fill=255)

    def line(self, L, a, b, w):
        A, B = self.T(*a), self.T(*b)
        w *= self.s
        self.d[L].line([(A[0] * SS, A[1] * SS), (B[0] * SS, B[1] * SS)], fill=255, width=max(1, int(w * SS)))
        for px, py in (A, B):
            self.d[L].ellipse([(px - w / 2) * SS, (py - w / 2) * SS, (px + w / 2) * SS, (py + w / 2) * SS], fill=255)


# ---------- karakter hewan ----------

def build_char(art, th, t, tail=True):
    kind = th['char']
    blink = t > 0.9 or t < 0.06
    ery = 0.22 if blink else 1.45
    eyes = [(13.6, 16.3), (20.4, 16.3)]
    cheek_y = 19.6
    mouth_c, mouth_r, span = (17, 19.9), 1.9, (20, 160)

    if kind == 'ghost':
        art.ell('sil', 17, 13.8, 9.6)
        art.poly('sil', [(7.4, 13.8), (26.6, 13.8), (26.6, 22.0), (7.4, 22.0)])
        for x in (9.6, 13.3, 17, 20.7, 24.4):
            art.ell('sil', x, 22.0, 2.1)
        eyes = [(13.6, 13.2), (20.4, 13.2)]
        cheek_y = 16.8
        mouth_c, mouth_r, span = (17, 17.4), 0.0, (0, 0)
    elif kind == 'penguin':
        art.ell('sil', 17, 17.5, 9.2, 10.6)
        art.ell('sil', 8.0, 19.5, 2.2, 4.4, ang=-20)
        art.ell('sil', 26.0, 19.5, 2.2, 4.4, ang=20)
        art.ell('light', 17, 21.5, 5.6, 6.8)
        art.poly('beak', [(22.6, 16.4), (27.8, 18.2), (22.6, 20.0)])
        eyes = [(13.6, 14.8), (20.4, 14.8)]
        cheek_y = 18.2
    elif kind == 'chick':
        art.ell('sil', 17, 18.0, 10.0)
        art.ell('beak', 15.0, 8.6, 2.2)
        art.ell('beak', 18.2, 7.4, 2.5)
        art.ell('beak', 21.0, 8.8, 2.0)
        art.ell('light', 17, 22.5, 5.4, 3.6)
        art.poly('beak', [(24.6, 15.8), (29.2, 17.8), (24.6, 19.6)])
        eyes = [(13.6, 16.6), (20.4, 16.6)]
        cheek_y = 19.8
    elif kind == 'frog':
        art.ell('sil', 17, 18.4, 9.8)
        art.ell('sil', 12.8, 10.2, 3.9)
        art.ell('sil', 21.2, 10.2, 3.9)
        art.ell('white', 12.8, 10.2, 2.5, 2.6)
        art.ell('white', 21.2, 10.2, 2.5, 2.6)
        eyes = [(12.8, 10.6), (21.2, 10.6)]
        cheek_y = 18.8
        mouth_c, mouth_r, span = (17, 18.6), 3.0, (25, 155)
    elif kind == 'panda':
        art.ell('sil', 17, 17, 9.4)
        art.ell('dark', 9.6, 9.4, 3.2)
        art.ell('dark', 24.4, 9.4, 3.2)
        art.ell('dark', 13.6, 16.3, 2.9, 2.4, ang=-15)
        art.ell('dark', 20.4, 16.3, 2.9, 2.4, ang=15)
    else:
        art.ell('sil', 17, 17, 9.2)

    if kind == 'cat':
        art.poly('sil', [(9.4, 12.4), (10.4, 3.2), (17.0, 8.2)])
        art.poly('sil', [(17.0, 8.2), (23.6, 3.2), (24.6, 12.4)])
        art.poly('light', [(11.4, 10.8), (11.8, 6.2), (15.2, 9.2)])
        art.poly('light', [(18.8, 9.2), (22.2, 6.2), (22.6, 10.8)])
        art.poly('ink', [(16.2, 18.4), (17.8, 18.4), (17.0, 19.4)])
    elif kind == 'bunny':
        art.ell('sil', 12.3, 6.2, 2.9, 6.6, ang=-12)
        art.ell('sil', 21.7, 6.2, 2.9, 6.6, ang=12)
        art.ell('light', 12.3, 6.6, 1.3, 4.6, ang=-12)
        art.ell('light', 21.7, 6.6, 1.3, 4.6, ang=12)
    elif kind == 'bear':
        art.ell('sil', 9.8, 9.8, 3.7)
        art.ell('sil', 24.2, 9.8, 3.7)
        art.ell('light', 9.8, 9.8, 1.9)
        art.ell('light', 24.2, 9.8, 1.9)
        art.ell('light', 17, 21.4, 4.2, 3.1)
        art.ell('ink', 17, 18.6, 1.3, 1.0)
    elif kind == 'fox':
        art.poly('sil', [(8.8, 13.4), (10.2, 1.8), (17.2, 8.2)])
        art.poly('sil', [(16.8, 8.2), (23.8, 1.8), (25.2, 13.4)])
        art.poly('light', [(11.2, 11.2), (11.6, 5.0), (15.2, 9.2)])
        art.poly('light', [(18.8, 9.2), (21.4, 5.0), (22.8, 11.2)])
        art.ell('light', 17, 21.6, 4.6, 3.2)
        art.ell('ink', 17, 19.2, 1.2, 0.9)
    elif kind == 'dino':
        art.poly('sil', [(11.5, 11.8), (13.8, 4.2), (16.2, 10.4)])
        art.poly('sil', [(14.6, 9.8), (17.2, 3.6), (19.6, 9.4)])
        art.poly('sil', [(18.6, 9.4), (21.2, 4.2), (23.2, 11.6)])
        art.ell('light', 17, 21.8, 5.0, 2.9)
        art.ell('ink', 17, 18.8, 1.1, 0.8)
    elif kind == 'panda':
        art.ell('white', 13.6, 16.3, 1.9, 1.9 * ery / 1.45)
        art.ell('white', 20.4, 16.3, 1.9, 1.9 * ery / 1.45)

    if kind == 'bear' or kind == 'cat' or kind == 'bunny' or kind == 'fox':
        pass

    if kind not in ('frog', 'penguin', 'chick', 'ghost', 'panda'):
        pass

    # mata
    for ex, ey in eyes:
        if kind == 'panda':
            art.ell('ink', ex, ey, 0.9, 0.9 * ery / 1.45 + 0.1)
        else:
            art.ell('ink', ex, ey, 1.35, ery)
            if not blink:
                art.ell('white', ex + 0.45, ey - 0.5, 0.5, 0.5)

    # pipi
    art.ell('cheek', eyes[0][0] - 1.8, cheek_y, 1.4, 0.9)
    art.ell('cheek', eyes[1][0] + 1.8, cheek_y, 1.4, 0.9)

    # mulut
    if kind == 'ghost':
        art.ell('ink', mouth_c[0], mouth_c[1], 1.0, 1.3)
    else:
        pts = []
        for a in range(span[0], span[1] + 1, 10):
            r = math.radians(a)
            pts.append((mouth_c[0] + mouth_r * math.cos(r), mouth_c[1] + mouth_r * math.sin(r)))
        for a, b in zip(pts, pts[1:]):
            art.line('ink', a, b, 0.45)

    if tail:
        art.poly('sil', [(3, 3), (14.5, 9.5), (9.5, 14.5)])


def help_bubble(art, t):
    bob = 0.4 * math.sin(TAU * t)
    art.ell('sil', 27, 6 + bob, 4.4)
    art.ell('white', 27, 6 + bob, 3.6)
    pts = [(27 + 1.5 * math.cos(math.radians(a)), 5.0 + bob + 1.5 * math.sin(math.radians(a)))
           for a in range(180, 361, 20)]
    for a, b in zip(pts, pts[1:]):
        art.line('ink', a, b, 0.5)
    art.line('ink', (27, 6.4 + bob), (27, 7.4 + bob), 0.5)
    art.ell('ink', 27, 8.9 + bob, 0.55)


def build_paw(art):
    art.ell('sil', 16, 19, 6.9, 5.7)
    for x, y, r in ((9.4, 12.6, 2.6), (13.6, 8.9, 2.8), (19.3, 8.9, 2.8), (23.2, 12.6, 2.6)):
        art.ell('sil', x, y, r)
    art.ell('light', 16, 20.8, 3.7, 2.8)
    for x, y in ((9.4, 12.8), (13.6, 9.2), (19.3, 9.2), (23.2, 12.8)):
        art.ell('light', x, y, 1.2)
    art.ell('white', 12.8, 17.5, 1.0, 0.7)


def spin(art, L, cx, cy, rad, t, n, size):
    for i in range(n):
        a = TAU * i / n
        k = ((i / n) - t) % 1.0
        s = size * (0.35 + 0.65 * (1 - k))
        art.ell(L, cx + rad * math.cos(a), cy + rad * math.sin(a), s)


def role_art(role, th, t):
    bob = 0.35 * math.sin(TAU * t)
    pulse = 0.5 + 0.5 * math.sin(TAU * t)

    if role in ('Arrow', 'Help', 'AppStarting'):
        art = Art(cy=17 + bob)
        build_char(art, th, t, True)
        if role == 'Help':
            help_bubble(art, t)
        if role == 'AppStarting':
            spin(art, 'accent', 25, 25, 4.0, t, 4, 1.7)
        return art

    if role == 'Hand':
        dy = -0.9 * max(0.0, math.sin(TAU * t))
        art = Art(cy=17 + dy)
        build_paw(art)
        return art

    if role == 'Wait':
        art = Art(s=0.72, cx=16, cy=17 + bob)
        build_char(art, th, t, False)
        return art

    art = Art(cy=17)
    if role == 'IBeam':
        w = 2.2 + 0.5 * pulse
        art.poly('sil', [(16 - w / 2, 5), (16 + w / 2, 5), (16 + w / 2, 27), (16 - w / 2, 27)])
        art.poly('sil', [(11, 3.5), (21, 3.5), (21, 5.8), (11, 5.8)])
        art.poly('sil', [(11, 26.2), (21, 26.2), (21, 28.5), (11, 28.5)])
        art.poly('light', [(15.4, 8), (15.9, 8), (15.9, 24), (15.4, 24)])
    elif role == 'Crosshair':
        r = 9.2 + 0.6 * pulse
        art.ell('sil', 16, 16, r)
        art.ell('white', 16, 16, r - 2.0)
        art.ell('accent', 16, 16, r - 4.2)
        art.ell('ink', 16, 16, 1.1)
    elif role in RESIZE_DIR:
        p = 1.2 * pulse
        th_ = math.radians(RESIZE_DIR[role])
        dx, dy = math.cos(th_), math.sin(th_)
        art.line('sil', (16 - dx * 7, 16 - dy * 7), (16 + dx * 7, 16 + dy * 7), 2.6)
        art.poly('sil', head_pts(16, 16, dx, dy, p))
        art.poly('sil', head_pts(16, 16, -dx, -dy, p))
    elif role == 'SizeAll':
        p = 1.2 * pulse
        art.line('sil', (8, 16), (24, 16), 2.4)
        art.line('sil', (16, 8), (16, 24), 2.4)
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            art.poly('sil', head_pts(16, 16, dx, dy, p))
    elif role == 'No':
        r = 10.2 + 0.6 * pulse
        art.ell('sil', 16, 16, r)
        art.ell('white', 16, 16, r - 2.2)
        art.line('ink', (10, 22), (22, 10), 2.2)
    elif role == 'UpArrow':
        art.poly('sil', [(16, 2.5), (25, 13), (19.6, 13), (19.6, 29), (12.4, 29), (12.4, 13), (7, 13)])
        art.poly('light', [(15, 15), (15.8, 15), (15.8, 26), (15, 26)])
    return art


# ---------- efek / partikel ----------

def poly_abs(D, pts, c):
    D.polygon([(x * SS, y * SS) for x, y in pts], fill=c)


def draw_particle(D, kind, col, x, y, s, a, ang=0.0):
    c = col + (max(0, min(255, a)),)
    if kind == 'heart':
        poly_abs(D, heart_pts(x, y, s), c)
    elif kind == 'spark':
        poly_abs(D, star_pts(x, y, s, 4, 0.28), c)
    elif kind == 'star':
        poly_abs(D, star_pts(x, y, s, 5, 0.45), c)
    elif kind == 'leaf':
        poly_abs(D, pol_ell(x, y, s * 0.9, s * 0.5, math.degrees(ang)), c)
    elif kind == 'bubble':
        D.ellipse([(x - s) * SS, (y - s) * SS, (x + s) * SS, (y + s) * SS],
                  outline=c, width=max(1, int(0.35 * SS)))
    elif kind == 'confetti':
        ca, sa = math.cos(ang), math.sin(ang)
        hw, hh = s * 0.7, s * 0.35
        corners = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
        poly_abs(D, [(x + u * ca - v * sa, y + u * sa + v * ca) for u, v in corners], c)
    elif kind in ('ember', 'snow'):
        D.ellipse([(x - s * 0.6) * SS, (y - s * 0.6) * SS, (x + s * 0.6) * SS, (y + s * 0.6) * SS], fill=c)
    elif kind == 'note':
        poly_abs(D, pol_ell(x, y, s * 0.55, s * 0.42, -20), c)
        D.line([((x + s * 0.5) * SS, y * SS), ((x + s * 0.5) * SS, (y - s * 2) * SS)],
               fill=c, width=max(1, int(0.4 * SS)))
        poly_abs(D, [(x + s * 0.5, y - s * 2), (x + s * 1.4, y - s * 1.5), (x + s * 0.5, y - s * 1.0)], c)


def deco_layer(role, th, t):
    layer = Image.new('RGBA', (BIG, BIG), (0, 0, 0, 0))
    D = ImageDraw.Draw(layer)
    kind = th['deco']
    cols = [hexrgb(c) for c in th['dc']]
    n = 4
    for i in range(n):
        c = cols[i % len(cols)]
        u = (t + i / n) % 1
        if role == 'Hand':
            ang = TAU * i / n + 0.4
            r = 1.5 + 6.5 * u
            draw_particle(D, kind, c, 14 + r * math.cos(ang), 6 + r * math.sin(ang),
                          1.2 + 0.6 * (1 - u), int(255 * (1 - u)), ang * 2)
        elif role == 'Wait':
            a = TAU * (t + i / n)
            draw_particle(D, kind, c, 16 + 13 * math.cos(a), 16 + 13 * math.sin(a), 1.5, 255, a)
        else:
            x = 25 + 2.4 * math.sin(TAU * (u + i * 0.23))
            y = 27 - 22 * u
            a = int(255 * math.sin(math.pi * u))
            draw_particle(D, kind, c, x, y, 1.5 + 0.5 * math.sin(TAU * u), a, TAU * u)
    return layer


# ---------- komposisi frame ----------

def paint(out, mask, color, alpha=1.0):
    layer = Image.new('RGBA', (BIG, BIG), color + (0,))
    a = mask if alpha >= 1 else mask.point(lambda v: int(v * alpha))
    layer.putalpha(a)
    return Image.alpha_composite(out, layer)


def render_frame(role, theme_id, t):
    th = THEMES[theme_id]
    main = hexrgb(th['main'])
    light = hexrgb(th['light'])
    dark = hexrgb(th['dark'])
    cheek = hexrgb(th['cheek'])
    accent = hexrgb(th['accent'])
    beak = hexrgb(th['beak'])
    pulse = 0.5 + 0.5 * math.sin(TAU * t)

    art = role_art(role, th, t)
    sil = art.m['sil']

    out = Image.new('RGBA', (BIG, BIG), (0, 0, 0, 0))
    aura = sil.filter(ImageFilter.GaussianBlur(10)).point(lambda v: int(min(255, v * 0.5 * (0.6 + 0.4 * pulse))))
    out = paint(out, aura, accent)
    outline = ImageChops.subtract(sil.filter(ImageFilter.MaxFilter(9)), sil)
    out = paint(out, outline, OUTLINE)
    out = paint(out, sil, main)
    out = paint(out, ImageChops.multiply(GRAD.point(lambda v: int(v * 0.5)), sil), dark)
    out = paint(out, art.m['light'], light)
    out = paint(out, art.m['dark'], dark)
    out = paint(out, art.m['cheek'], cheek, 0.8)
    out = paint(out, art.m['beak'], beak)
    out = paint(out, art.m['accent'], accent)
    out = paint(out, art.m['white'], (255, 255, 255))
    out = paint(out, art.m['ink'], INK)
    out = Image.alpha_composite(out, deco_layer(role, th, t))

    return out.resize((SIZE, SIZE), Image.LANCZOS)


# ---------- format .ani Windows ----------

def to_cur(img, hot):
    buf = io.BytesIO()
    img.save(buf, format='ICO', sizes=[(SIZE, SIZE)])
    data = bytearray(buf.getvalue())
    data[2:4] = struct.pack('<H', 2)
    data[10:12] = struct.pack('<H', hot[0])
    data[12:14] = struct.pack('<H', hot[1])
    return bytes(data)


def chunk(cid, data):
    pad = b'\x00' if len(data) % 2 else b''
    return cid + struct.pack('<I', len(data)) + data + pad


def build_ani(frames):
    anih = struct.pack('<9I', 36, len(frames), len(frames), SIZE, SIZE, 32, 1, JIFFY, 1)
    icons = b''.join(chunk(b'icon', f) for f in frames)
    body = b'ACON' + chunk(b'anih', anih) + chunk(b'LIST', b'fram' + icons)
    return b'RIFF' + struct.pack('<I', len(body)) + body


# ---------- build ----------

def build_theme(theme_id):
    out_dir = os.path.join(ASSETS, 'themes', theme_id)
    os.makedirs(out_dir, exist_ok=True)
    rendered = {}
    for role, hot in ROLES.items():
        frames = [render_frame(role, theme_id, i / FRAMES) for i in range(FRAMES)]
        rendered[role] = frames
        with open(os.path.join(out_dir, f'{role}.ani'), 'wb') as fh:
            fh.write(build_ani([to_cur(f, hot) for f in frames]))
    return rendered


def build_preview(theme_id, rendered):
    cell = 72
    frames = []
    for i in range(FRAMES):
        strip = Image.new('RGB', (len(PREVIEW_ROLES) * cell, cell), PREVIEW_BG)
        for k, role in enumerate(PREVIEW_ROLES):
            img = rendered[role][i].resize((64, 64), Image.LANCZOS)
            strip.paste(img, (k * cell + 4, 4), img)
        frames.append(strip.quantize(colors=128))
    frames[0].save(os.path.join(ASSETS, 'preview', f'{theme_id}.gif'),
                   save_all=True, append_images=frames[1:], duration=67, loop=0, disposal=2)


def main():
    os.makedirs(os.path.join(ASSETS, 'preview'), exist_ok=True)
    themes, tray_done = [], False
    for theme_id, th in THEMES.items():
        print(f'Membuat {th["name"]} ...', flush=True)
        rendered = build_theme(theme_id)
        build_preview(theme_id, rendered)
        if not tray_done:
            rendered['Arrow'][0].save(os.path.join(ASSETS, 'tray.png'))
            tray_done = True
        themes.append({'id': theme_id, 'name': th['name']})
    with open(os.path.join(ASSETS, 'themes.json'), 'w', encoding='utf-8') as fh:
        json.dump(themes, fh, ensure_ascii=False, indent=2)
    print(f'Selesai: {len(THEMES)} tema x {len(ROLES)} kursor.')


if __name__ == '__main__':
    main()
