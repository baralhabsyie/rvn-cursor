# Rvn Cursor

Kursor karakter animasi untuk Windows. Mengganti seluruh jenis kursor sistem
(panah, loading, sibuk di background, pilih teks, pilih tautan, resize, presisi, dan lainnya)
dengan 10 tema karakter. Klik kanan ikon di tray untuk membuka pengaturan.

## Menjalankan

    npm install
    npm run gen      (hanya jika ingin membuat ulang aset kursor)
    npm start

## Fitur

- 10 tema karakter, masing-masing dengan 14 jenis kursor animasi
- Halaman pengaturan: pilih tema utama, atau atur tiap fungsi kursor dengan tema berbeda
- Auto start saat Windows menyala, berjalan di tray
- Kursor asli dikembalikan saat aplikasi ditutup

## Tombol dan perintah

- **Ctrl + Shift + Q**: keluar dan kembalikan kursor asli
- **npm run restore**: kembalikan kursor asli tanpa membuka aplikasi (dipakai jika aplikasi dimatikan paksa)

## Membuat installer

    npm run build

Installer ada di folder `dist/`.

## Mengubah tema

Edit `tools/make_cursors.py` (bentuk di `ROLES`, `THEMES`, dan fungsi `deco`/`role_mask`),
lalu jalankan `npm run gen`.

## Catatan

- Data pengaturan disimpan di `%APPDATA%\RvnCursor\config.json`.
- Kursor asli disimpan di `%APPDATA%\RvnCursor\original-cursors.json` dan dikembalikan saat keluar.
- Tidak membutuhkan hak administrator.
